
UPDATE `engine4_core_menuitems`
SET `plugin` = 'User_Plugin_Menus'
WHERE `name` = 'user_edit_style';
