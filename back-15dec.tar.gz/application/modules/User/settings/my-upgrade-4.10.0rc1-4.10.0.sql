INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES

('user_delete_photos', 'user', 'Delete Profile Photos', 'User_Plugin_Menus', '', 'user_edit', '', 4);