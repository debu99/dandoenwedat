ALTER TABLE `engine4_users` ADD `coverphotoparams` VARCHAR(265) NULL DEFAULT NULL;
