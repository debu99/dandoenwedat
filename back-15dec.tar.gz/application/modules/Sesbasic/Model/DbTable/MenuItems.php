<?php
class Sesbasic_Model_DbTable_MenuItems extends Engine_Db_Table {

  protected $_rowClass = 'Sesbasic_Model_MenuItem';
  protected $_serializedColumns = array('params');

  
}
