INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
('sesbasic_admin_manage', 'sesbasic', 'Manage Video Lightbox', '', '{"route":"admin_default","module":"sesbasic","controller":"lightbox","action":"video"}', 'sesbasic_admin_main', '', 4),
('sesbasic_admin_memberlevel', 'sesbasic', 'Member Level Setting', '', '{"route":"admin_default","module":"sesbasic","controller":"lightbox","action":"index"}', 'sesbasic_admin_manage', '', 2),
('sesbasic_admin_videolightbox', 'sesbasic', 'Video Lightbox Settings', '', '{"route":"admin_default","module":"sesbasic","controller":"lightbox","action":"video"}', 'sesbasic_admin_manage', '', 1);

