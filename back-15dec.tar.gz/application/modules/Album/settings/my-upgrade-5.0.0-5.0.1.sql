UPDATE `engine4_album_albums` SET `view_privacy` = 'owner' WHERE `engine4_album_albums`.`type` = 'message';
